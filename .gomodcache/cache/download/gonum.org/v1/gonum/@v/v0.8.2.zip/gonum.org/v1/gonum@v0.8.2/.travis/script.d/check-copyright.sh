#!/bin/bash

set -e
check-copyright -notice "Copyright ©20[0-9]{2} The Gonum Authors\. All rights reserved\."
