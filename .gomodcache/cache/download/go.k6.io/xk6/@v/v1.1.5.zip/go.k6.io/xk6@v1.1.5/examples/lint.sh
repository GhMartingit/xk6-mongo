xk6 lint --passing D
