Display version information

The version is printed to standard output in the following format:

    xk6 version XXX

XXX is the semantic version of xk6, without the v prefix.
