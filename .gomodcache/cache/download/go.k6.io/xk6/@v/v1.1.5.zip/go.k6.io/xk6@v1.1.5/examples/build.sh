xk6 build --with github.com/grafana/xk6-example --with github.com/grafana/xk6-output-example
