Building private extensions

To build an `xk6` extension from a private Git repository, you need to configure your environment to handle authentication.

**Core Prerequisite**

First, you must set the **`GOPRIVATE`** environment variable. This tells the Go compiler to bypass the standard Go proxy for your repository, allowing it to access the private module directly.

    export GOPRIVATE=github.com/owner/repo

**Method 1: Using SSH**

To handle authentication in non-interactive environments like CI/CD pipelines, configure Git to use the **SSH protocol** instead of HTTPS. This allows for authentication with an SSH key. This command globally configures Git to rewrite any `https://github.com/` URLs to `ssh://git@github.com/`.

    git config --global url.ssh://git@github.com/.insteadOf https://github.com/

**Method 2: Using GitHub CLI**

An alternative to using SSH is to leverage the **GitHub CLI** as a Git credential helper. In this case, Git will still access the repository over HTTPS, but it will use the GitHub CLI to handle the authentication process, eliminating the need to manually enter a password.

    git config --global --add 'credential.https://github.com.helper' '!gh auth git-credential'
