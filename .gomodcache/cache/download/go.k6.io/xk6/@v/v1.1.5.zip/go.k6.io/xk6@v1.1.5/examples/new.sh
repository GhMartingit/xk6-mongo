xk6 new -d "Experimenting with k6 extensions" example.com/user/xk6-demo
