# randomstring

Generate random strings.

Used by [cookie](https://github.com/xyproto/cookie) and [alienpdf](https://github.com/xyproto/alienpdf/).

* Version: 1.0.5
* License: BSD-3
