// Package storer defines the interfaces to store objects, references, etc.
package storer
