package osfs

type Option func(*options)
