"use k6 with k6/x/faker>v0.3.0";
"use k6 with xk6-top";
console.log("Hello, World");
