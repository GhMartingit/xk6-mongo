<!--
SPDX-FileCopyrightText: 2023 Raintank, Inc. dba Grafana Labs

SPDX-License-Identifier: AGPL-3.0-only
-->

xk6-dashboard `<version>` is here 🎉! This release includes:

- (_optional_) `<highlight of breaking changes>`
- `<Summary of new features>` (_one or multiple bullets_)


## Breaking changes

- `#pr`, `<small_break_1>`
- `#pr`, `<small_break_2>`

### (_optional h3_) `<big_breaking_change>` `#pr`

## New features

_optional intro here_

### `<big_feature_1>` `#pr`

_what, why, and what this means for the user_

### `<big_feature_n>` `#pr`

_what, why, and what this means for the user_

### UX improvements and enhancements

_Format as `<number> <present_verb> <object>. <credit>`_:

- _`#999` Gives terminal output prettier printing. Thanks to `@person` for the help!_
- `#pr` `<description>`
- `#pr` `<description>`

## Bug fixes

_Format as `<number> <present_verb> <object>. <credit>`_:
- _`#111` fixes race condition in runtime_

## Maintenance and internal improvements

_Format as `<number> <present_verb> <object>. <credit>`_:
- _`#2770` Refactors parts of the JS module._

## _Optional_ Roadmap

_Discussion of future plans_
