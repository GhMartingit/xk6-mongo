//go:build windows
// +build windows

package k6provider

const k6Binary = "k6.exe"
