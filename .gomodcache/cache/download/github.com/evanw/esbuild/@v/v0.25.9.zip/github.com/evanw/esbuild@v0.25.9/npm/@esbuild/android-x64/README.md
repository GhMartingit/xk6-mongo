# esbuild

This is a WebAssembly shim for esbuild on Android x64. See https://github.com/evanw/esbuild for details.
