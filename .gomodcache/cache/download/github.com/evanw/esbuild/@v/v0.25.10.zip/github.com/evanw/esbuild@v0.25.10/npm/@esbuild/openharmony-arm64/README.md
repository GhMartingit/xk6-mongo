# esbuild

This is a WebAssembly shim for esbuild on OpenHarmony ARM64. See https://github.com/evanw/esbuild for details.
