# esbuild

This is the IBM AIX PowerPC 64-bit binary for esbuild, a JavaScript bundler and minifier. See https://github.com/evanw/esbuild for details.
