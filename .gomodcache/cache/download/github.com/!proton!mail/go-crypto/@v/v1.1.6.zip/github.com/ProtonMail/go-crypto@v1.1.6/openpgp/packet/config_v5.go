//go:build !v5

package packet

func init() {
	V5Disabled = true
}
