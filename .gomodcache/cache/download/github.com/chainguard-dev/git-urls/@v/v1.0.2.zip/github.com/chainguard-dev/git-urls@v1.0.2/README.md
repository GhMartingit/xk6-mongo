# git-urls

Docs: https://pkg.go.dev/github.com/chainguard-dev/git-urls?tab=overview


This repository is a fork of [git-urls](https://github.com/whilp/git-urls). The fork was created to fix an existing vulnerability [GHSA-3f2q-6294-fmq5](https://github.com/advisories/GHSA-3f2q-6294-fmq5) in the upstream repository, which looked unmaintained.

Chainguard plans to keep maintaining this repository under our organization.
