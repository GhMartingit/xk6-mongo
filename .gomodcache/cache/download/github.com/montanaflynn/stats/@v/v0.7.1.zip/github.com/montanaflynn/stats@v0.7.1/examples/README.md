# examples

The examples directory provides some examples of using the stats package.