# About sysutil

Package sysutil provides some utilities for working with cross platform
systems.

Inspired by the Go version of Sigar, but written to be "idiomatic" Go.
