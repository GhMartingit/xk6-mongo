## Generating Fish Completions For Your cobra.Command

Please refer to [Shell Completions](shell_completions.md) for details.

