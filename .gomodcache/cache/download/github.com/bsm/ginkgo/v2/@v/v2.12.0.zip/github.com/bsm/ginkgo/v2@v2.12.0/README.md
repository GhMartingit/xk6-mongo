# Ginkgo

This is a straight copy of the excellent [Ginkgo](http://onsi.github.io/ginkgo/) library,
stripped to the bare core to be free of third-party dependencies.
