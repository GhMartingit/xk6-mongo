go-minhash: bottom-k and minhash LSH implementations

godoc: http://godoc.org/github.com/dgryski/go-minhash
