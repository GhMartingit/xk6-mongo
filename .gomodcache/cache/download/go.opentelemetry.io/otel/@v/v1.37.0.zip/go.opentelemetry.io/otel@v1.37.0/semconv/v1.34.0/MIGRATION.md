<!-- Generated. DO NOT MODIFY. -->
# Migration from v1.33.0 to v1.34.0

The `go.opentelemetry.io/otel/semconv/v1.34.0` package should be a drop-in replacement for `go.opentelemetry.io/otel/semconv/v1.33.0`.
