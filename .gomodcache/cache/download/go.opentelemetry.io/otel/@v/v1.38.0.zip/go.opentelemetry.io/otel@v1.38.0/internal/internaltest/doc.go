// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Package internaltest provides testing functionality.
package internaltest // import "go.opentelemetry.io/otel/internal/internaltest"
